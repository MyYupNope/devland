import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// Set up the scene, camera, and renderer
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Add controls
const controls = new OrbitControls(camera, renderer.domElement);

// Set up the player's ship
const shipGeometry = new THREE.BoxGeometry(1, 0.2, 0.5);
const shipMaterial = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const ship = new THREE.Mesh(shipGeometry, shipMaterial);
scene.add(ship);
ship.position.set(0, -5, -5);

// Set up clock for frame-rate independent updates
const clock = new THREE.Clock();

// Game State variables
let score = 0;
let level = 1;
let highScore = parseInt(localStorage.getItem('space_invaders_3d_highscore') || '0', 10);
let gameState = 'PLAYING'; // 'PLAYING', 'GAME_OVER', 'LEVEL_COMPLETE'

// Invader Movement settings
let invaderDirection = 1; // 1 = right, -1 = left
const invaderBaseSpeed = 1.2; // base horizontal movement speed
const invaderDropAmount = 0.4; // how much they drop when hitting screen edge

// --- 3D Native HUD Panel ---
const hudCanvas = document.createElement('canvas');
hudCanvas.width = 2048;
hudCanvas.height = 512;
const hudCtx = hudCanvas.getContext('2d');

const hudTexture = new THREE.CanvasTexture(hudCanvas);
// Apply maximum anisotropy to prevent blur at angles
const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
hudTexture.anisotropy = maxAnisotropy;
hudTexture.minFilter = THREE.LinearFilter;
hudTexture.magFilter = THREE.LinearFilter;
hudTexture.generateMipmaps = false;

const hudMaterial = new THREE.MeshBasicMaterial({ map: hudTexture, transparent: true });
const hudGeometry = new THREE.PlaneGeometry(6, 1.5);
const hudMesh = new THREE.Mesh(hudGeometry, hudMaterial);
hudMesh.position.set(0, 8.5, -5);
scene.add(hudMesh);

function updateHUDCanvas() {
    hudCtx.clearRect(0, 0, hudCanvas.width, hudCanvas.height);
    
    // Draw background (glassmorphic panel)
    hudCtx.fillStyle = 'rgba(10, 10, 25, 0.7)';
    hudCtx.beginPath();
    hudCtx.roundRect(0, 0, hudCanvas.width, hudCanvas.height, 64);
    hudCtx.fill();
    hudCtx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    hudCtx.lineWidth = 8;
    hudCtx.stroke();
    
    // Draw text values
    hudCtx.textAlign = 'center';
    hudCtx.textBaseline = 'middle';
    
    // Score
    hudCtx.font = 'bold 84px "Orbitron", sans-serif';
    hudCtx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    hudCtx.fillText('SCORE', hudCanvas.width / 6, 160);
    hudCtx.fillStyle = '#ffffff';
    hudCtx.font = '900 128px "Orbitron", sans-serif';
    hudCtx.fillText(score.toString(), hudCanvas.width / 6, 340);
    
    // Level
    hudCtx.font = 'bold 84px "Orbitron", sans-serif';
    hudCtx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    hudCtx.fillText('LEVEL', hudCanvas.width / 2, 160);
    hudCtx.fillStyle = '#00f3ff';
    hudCtx.font = '900 128px "Orbitron", sans-serif';
    hudCtx.fillText(level.toString(), hudCanvas.width / 2, 340);
    
    // High Score
    hudCtx.font = 'bold 84px "Orbitron", sans-serif';
    hudCtx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    hudCtx.fillText('HIGH SCORE', (5 * hudCanvas.width) / 6, 160);
    hudCtx.fillStyle = '#39ff14';
    hudCtx.font = '900 128px "Orbitron", sans-serif';
    hudCtx.fillText(highScore.toString(), (5 * hudCanvas.width) / 6, 340);
    
    hudTexture.needsUpdate = true;
}
updateHUDCanvas();

// --- 3D Native Overlays and Interactive Buttons ---
const overlayCanvas = document.createElement('canvas');
overlayCanvas.width = 2048;
overlayCanvas.height = 1536;
const overlayCtx = overlayCanvas.getContext('2d');
const overlayTexture = new THREE.CanvasTexture(overlayCanvas);
overlayTexture.anisotropy = maxAnisotropy;
overlayTexture.minFilter = THREE.LinearFilter;
overlayTexture.magFilter = THREE.LinearFilter;
overlayTexture.generateMipmaps = false;
const overlayMaterial = new THREE.MeshBasicMaterial({ map: overlayTexture, transparent: true, depthTest: false });
const overlayGeometry = new THREE.PlaneGeometry(6, 4.5);
const overlayMesh = new THREE.Mesh(overlayGeometry, overlayMaterial);
overlayMesh.position.set(0, 1, -4.2);

const buttonCanvas = document.createElement('canvas');
buttonCanvas.width = 2048;
buttonCanvas.height = 768; // 8:3 aspect ratio to match plane
const buttonCtx = buttonCanvas.getContext('2d');
const buttonTexture = new THREE.CanvasTexture(buttonCanvas);
buttonTexture.anisotropy = maxAnisotropy;
buttonTexture.minFilter = THREE.LinearFilter;
buttonTexture.magFilter = THREE.LinearFilter;
buttonTexture.generateMipmaps = false;
const buttonMaterial = new THREE.MeshBasicMaterial({ map: buttonTexture, transparent: true, depthTest: false });
const buttonGeometry = new THREE.PlaneGeometry(3.2, 1.2);
const buttonMesh = new THREE.Mesh(buttonGeometry, buttonMaterial);
buttonMesh.position.set(0, -2.2, -4.2);

function drawOverlayCanvas() {
    overlayCtx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
    
    // Draw background glass card
    overlayCtx.fillStyle = 'rgba(15, 15, 35, 0.95)';
    overlayCtx.beginPath();
    overlayCtx.roundRect(0, 0, overlayCanvas.width, overlayCanvas.height, 96);
    overlayCtx.fill();
    overlayCtx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    overlayCtx.lineWidth = 12;
    overlayCtx.stroke();
    
    // Draw Title
    overlayCtx.textAlign = 'center';
    overlayCtx.textBaseline = 'middle';
    
    if (gameState === 'GAME_OVER') {
        overlayCtx.shadowColor = '#ff0055';
        overlayCtx.shadowBlur = 60;
        overlayCtx.fillStyle = '#ff007f';
        overlayCtx.font = '900 160px "Orbitron", sans-serif';
        overlayCtx.fillText('GAME OVER', overlayCanvas.width / 2, 280);
        
        overlayCtx.shadowBlur = 0;
        overlayCtx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        overlayCtx.font = 'bold 72px "Orbitron", sans-serif';
        overlayCtx.fillText('The space invaders have conquered Earth!', overlayCanvas.width / 2, 540);
    } else if (gameState === 'LEVEL_COMPLETE') {
        overlayCtx.shadowColor = '#00ff87';
        overlayCtx.shadowBlur = 60;
        overlayCtx.fillStyle = '#00ff87';
        overlayCtx.font = '900 160px "Orbitron", sans-serif';
        overlayCtx.fillText('WAVE CLEARED', overlayCanvas.width / 2, 280);
        
        overlayCtx.shadowBlur = 0;
        overlayCtx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        overlayCtx.font = 'bold 72px "Orbitron", sans-serif';
        overlayCtx.fillText(`Excellent job! Wave ${level} completed.`, overlayCanvas.width / 2, 540);
    }
    
    // Score container (shifted to fit the larger resolution)
    overlayCtx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    overlayCtx.beginPath();
    overlayCtx.roundRect(200, 780, overlayCanvas.width - 400, 400, 48);
    overlayCtx.stroke();
    
    overlayCtx.font = 'bold 72px "Orbitron", sans-serif';
    overlayCtx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    overlayCtx.fillText('FINAL SCORE', overlayCanvas.width / 2, 890);
    
    overlayCtx.fillStyle = '#39ff14';
    overlayCtx.font = '900 128px "Orbitron", sans-serif';
    overlayCtx.fillText(score.toString(), overlayCanvas.width / 2, 1030);
    
    overlayTexture.needsUpdate = true;
}

function drawButtonCanvas(isHovered) {
    buttonCtx.clearRect(0, 0, buttonCanvas.width, buttonCanvas.height);
    
    // Draw button background
    if (isHovered) {
        buttonCtx.fillStyle = '#39ff14';
        buttonCtx.shadowColor = '#39ff14';
        buttonCtx.shadowBlur = 80;
    } else {
        buttonCtx.fillStyle = '#00f3ff';
        buttonCtx.shadowColor = '#00f3ff';
        buttonCtx.shadowBlur = 48;
    }
    
    buttonCtx.beginPath();
    buttonCtx.roundRect(40, 40, buttonCanvas.width - 80, buttonCanvas.height - 80, 96);
    buttonCtx.fill();
    
    // Draw button text
    buttonCtx.shadowBlur = 0;
    buttonCtx.fillStyle = '#000000';
    buttonCtx.font = '900 152px "Orbitron", sans-serif';
    buttonCtx.textAlign = 'center';
    buttonCtx.textBaseline = 'middle';
    
    const btnText = gameState === 'GAME_OVER' ? 'PLAY AGAIN' : 'NEXT WAVE';
    buttonCtx.fillText(btnText, buttonCanvas.width / 2, buttonCanvas.height / 2);
    
    buttonTexture.needsUpdate = true;
}

function showOverlay() {
    drawOverlayCanvas();
    drawButtonCanvas(false);
    scene.add(overlayMesh);
    scene.add(buttonMesh);
}

function hideOverlay() {
    scene.remove(overlayMesh);
    scene.remove(buttonMesh);
}

// Redraw canvases when custom fonts are ready
document.fonts.ready.then(() => {
    updateHUDCanvas();
    if (gameState !== 'PLAYING') {
        drawOverlayCanvas();
        drawButtonCanvas(isButtonHovered);
    }
});

// Set up the invaders
const invaders = [];
const invaderGeometry = new THREE.BoxGeometry(0.5, 0.5, 0.5);
const invaderMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });

function spawnInvaders() {
    for (let i = 0; i < invaders.length; i++) {
        scene.remove(invaders[i]);
    }
    invaders.length = 0;

    for (let x = -5; x <= 5; x += 2) {
        for (let y = 2; y <= 6; y += 2) {
            const invader = new THREE.Mesh(invaderGeometry, invaderMaterial);
            invader.position.set(x, y, -5);
            scene.add(invader);
            invaders.push(invader);
        }
    }
}
spawnInvaders();

// Set up bullet resources globally
const bullets = [];
const bulletGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
const bulletMaterial = new THREE.MeshBasicMaterial({ color: 0x00ffff });

function clearBullets() {
    for (let i = 0; i < bullets.length; i++) {
        scene.remove(bullets[i]);
    }
    bullets.length = 0;
}

// Set up the camera position
camera.position.z = 10;

// Handle keyboard input
const keys = {};
document.addEventListener('keydown', (event) => {
    keys[event.key] = true;
});

document.addEventListener('keyup', (event) => {
    keys[event.key] = false;
});

// Handle shooting (only instantiates mesh, no redundant loops/geometries/materials)
function shoot() {
    const bullet = new THREE.Mesh(bulletGeometry, bulletMaterial);
    bullet.position.set(ship.position.x, ship.position.y + 0.5, ship.position.z);
    scene.add(bullet);
    bullets.push(bullet);
}

// Add event listener for shooting
document.addEventListener('keydown', (event) => {
    if (event.key === ' ' && gameState === 'PLAYING') {
        shoot();
    }
});

// Handle game state overlays
function triggerGameOver() {
    gameState = 'GAME_OVER';
    showOverlay();
}

function triggerLevelComplete() {
    gameState = 'LEVEL_COMPLETE';
    showOverlay();
}

// Game loop
function animate() {
    requestAnimationFrame(animate);

    controls.update();
    renderer.render(scene, camera);

    if (gameState !== 'PLAYING') {
        return;
    }

    const delta = clock.getDelta();

    // Move the ship based on keyboard input (frame-rate independent)
    const shipSpeed = 10 * delta; // 10 units per second
    if (keys['ArrowLeft'] && ship.position.x > -6) {
        ship.position.x -= shipSpeed;
    }
    if (keys['ArrowRight'] && ship.position.x < 6) {
        ship.position.x += shipSpeed;
    }

    // Move invaders side-to-side and down when reaching edges
    let changeDirection = false;
    const invaderSpeed = (invaderBaseSpeed + level * 0.4) * delta;
    
    for (let i = 0; i < invaders.length; i++) {
        invaders[i].position.x += invaderSpeed * invaderDirection;
        if (invaderDirection === 1 && invaders[i].position.x > 6) {
            changeDirection = true;
        } else if (invaderDirection === -1 && invaders[i].position.x < -6) {
            changeDirection = true;
        }
    }

    if (changeDirection) {
        invaderDirection *= -1;
        for (let i = 0; i < invaders.length; i++) {
            invaders[i].position.y -= invaderDropAmount;
            if (invaders[i].position.y <= -4.5) {
                triggerGameOver();
                return;
            }
        }
    }

    // Update bullets (unified updates & collision checks in the main loop)
    const bulletSpeed = 15 * delta; // 15 units per second
    for (let i = bullets.length - 1; i >= 0; i--) {
        const bullet = bullets[i];
        bullet.position.y += bulletSpeed;

        if (bullet.position.y > 10) {
            scene.remove(bullet);
            bullets.splice(i, 1);
        } else {
            // Check for collisions with invaders
            for (let j = invaders.length - 1; j >= 0; j--) {
                const invader = invaders[j];
                const distance = bullet.position.distanceTo(invader.position);
                if (distance < 0.8) {
                    scene.remove(bullet);
                    bullets.splice(i, 1);
                    scene.remove(invader);
                    invaders.splice(j, 1);

                    // Update score & high score
                    score += 100 * level;
                    if (score > highScore) {
                        highScore = score;
                        localStorage.setItem('space_invaders_3d_highscore', highScore.toString());
                    }
                    updateHUDCanvas();

                    // Check level completion
                    if (invaders.length === 0) {
                        triggerLevelComplete();
                    }
                    break;
                }
            }
        }
    }
}

animate();

// --- 3D Raycasting Mouse Interactions ---
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let isButtonHovered = false;

window.addEventListener('mousemove', (event) => {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    
    if (gameState !== 'PLAYING') {
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObject(buttonMesh);
        
        if (intersects.length > 0) {
            if (!isButtonHovered) {
                isButtonHovered = true;
                document.body.style.cursor = 'pointer';
                drawButtonCanvas(true);
                buttonMesh.scale.set(1.08, 1.08, 1);
            }
        } else {
            if (isButtonHovered) {
                isButtonHovered = false;
                document.body.style.cursor = 'default';
                drawButtonCanvas(false);
                buttonMesh.scale.set(1, 1, 1);
            }
        }
    } else {
        document.body.style.cursor = 'default';
    }
});

window.addEventListener('click', () => {
    if (gameState !== 'PLAYING') {
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObject(buttonMesh);
        
        if (intersects.length > 0) {
            if (gameState === 'GAME_OVER') {
                score = 0;
                level = 1;
            } else if (gameState === 'LEVEL_COMPLETE') {
                level++;
            }
            
            spawnInvaders();
            clearBullets();
            ship.position.set(0, -5, -5);
            invaderDirection = 1;
            gameState = 'PLAYING';
            updateHUDCanvas();
            hideOverlay();
            isButtonHovered = false;
            document.body.style.cursor = 'default';
            clock.getDelta(); // reset delta accumulator
        }
    }
});

// Handle window resize
window.addEventListener('resize', () => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    renderer.setSize(width, height);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
});
